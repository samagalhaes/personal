/*
 * lcd.h
 *
 *  Created on: 02/12/2015
 *      Author: sandr
 */

/***************************************************************************

            The four data lines as well as the two control lines may be
              implemented on any available I/O pin of any port.  These are
              the connections used for this program:

                 -----------                   ----------
                | ATmega328 |                 |   LCD    |
                |           |                 |          |
                |        PD7|---------------->|D7        |
                |        PD6|---------------->|D6        |
                |        PD5|---------------->|D5        |
                |        PD4|---------------->|D4        |
                |           |                 |D3        |
                |           |                 |D2        |
                |           |                 |D1        |
                |           |                 |D0        |
                |           |                 |          |
                |        PD3|---------------->|E         |
                |           |         GND --->|RW        |
                |        PD2|---------------->|RS        |
                 -----------                   ----------

  **************************************************************************/

#define F_CPU 16000000UL

/*** Configure Instructions Commands ***/
#define lcd_clear 0b00000001
#define lcd_cursorhome 0b00000010
#define lcd_on 0b00001100
#define lcd_off 0b00001000
#define lcd_mode 0b00101100
#define lcd_entrymode 0b00000110
#define lcd_SetCursor 0b10000000

/*** Configure LCD Pins ***/
#define LCD_RS PD2
#define LCD_E PD3
#define LCD_PORT PORTD
#define LCD_DDR DDRD

/*** Configure LCD Data Pins ***/
#define DATA4 PD4
#define DATA5 PD5
#define DATA6 PD6
#define DATA7 PD7
#define DATA_PORT PORTD
#define DATA_DDR DDRD

/*** LCD Function ***/
void lcd_init(void);
void lcd_wr_str (uint8_t str[]);
void lcd_wr_char (uint8_t data);
void lcd_wr_inst (uint8_t instruction);
void lcd_write (uint8_t byte);
ite (uint8_t byte);
