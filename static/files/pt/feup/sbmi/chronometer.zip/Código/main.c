/*
 * main.c
 *
 *  Projecto SBMI
 *  Created on: 18/11/2015
 *      Author: Sandro Magalh�es
 */


#include <avr/io.h>
#include <avr/interrupt.h>
//#include <util/delay.h>
//#include <stdio.h>
//#include <string.h>
//#include "printf_tools.h"
#include "lcd.h"
#include "usart.h"
#include "display7.h"

#define INIT_COUNTER (255-250)

#define START PC0
#define STOP PC1

#define LCD_RS PD2
#define LCD_E PD3
#define DATA4 PD4
#define DATA5 PD5
#define DATA6 PD6
#define DATA7 PD7
#define LCD_PORT PORTD
#define LCD_DDR DDRD
#define DATA_PORT PORTD
#define DATA_DDR DDRD

#define lcd_SetCursor 0b10000000
#define lcd_1line 0x00
#define lcd_2line 0x3F

volatile uint16_t timer = 0, timer0 = 0;
volatile uint8_t display=1;
uint8_t str_timer[17]="          0,00 s ";

ISR (TIMER0_OVF_vect){
	TCNT0 = INIT_COUNTER;
	timer0++;

	if (!(timer0%10)) timer++;

	display7_print_time(str_timer, display);
	if (display == 3) display = 1;
	else display++;
}

void init_timers (void){
	TCCR0A &= ~((1<<WGM01)|(1<<WGM00));
	TCCR0B &= ~((1<<WGM02));

	TCCR0B &= ~((1<<CS02));
	TCCR0B |= (1<<CS01)|(1<<CS00);

	TIMSK0 |= (1<<TOIE0);
	TCNT0 = INIT_COUNTER;
}

void define_ports (void){
	DDRC &= ~((1<<START)|(1<<STOP));
	PORTC |= ((1<<START) | (1<<STOP));
	MCUCR &= ~(1<<PUD);
}

uint8_t* convert_str(uint16_t value, uint8_t str[17]){
	_Bool aux=0;
	uint8_t num;

	if ((num = value/10000) != 0){
		aux = 1;

		str[8] = num + '0';

		/*
		switch ((value/10000)){
		case 0: str[8] = '0'; break;
		case 1: str[8] = '1'; break;
		case 2: str[8] = '2'; break;
		case 3: str[8] = '3'; break;
		case 4: str[8] = '4'; break;
		case 5: str[8] = '5'; break;
		case 6: str[8] = '6'; break;
		case 7: str[8] = '7'; break;
		case 8: str[8] = '8'; break;
		case 9: str[8] = '9'; break;
		}*/
	}
	else str[8]=' ';

	if (((num = (value%10000)/1000) != 0)  || aux==1){
		aux = 1;

		str[9] = num + '0';

		/*
		switch ((value%10000)/1000){
		case 0: str[9] = '0'; break;
		case 1: str[9] = '1'; break;
		case 2: str[9] = '2'; break;
		case 3: str[9] = '3'; break;
		case 4: str[9] = '4'; break;
		case 5: str[9] = '5'; break;
		case 6: str[9] = '6'; break;
		case 7: str[9] = '7'; break;
		case 8: str[9] = '8'; break;
		case 9: str[9] = '9'; break;
		}*/
	}
	else str[9] = ' ';

		str[10] = (value%1000)/100 + '0';

		/*
		switch ((value%1000)/100){
		case 0: str[10] = '0'; break;
		case 1: str[10] = '1'; break;
		case 2: str[10] = '2'; break;
		case 3: str[10] = '3'; break;
		case 4: str[10] = '4'; break;
		case 5: str[10] = '5'; break;
		case 6: str[10] = '6'; break;
		case 7: str[10] = '7'; break;
		case 8: str[10] = '8'; break;
		case 9: str[10] = '9'; break;
		}*/

		str[12] = (value%100)/10 + '0';

		/*
		switch (value%100/10){
		case 0: str[11] = '0'; break;
		case 1: str[11] = '1'; break;
		case 2: str[11] = '2'; break;
		case 3: str[11] = '3'; break;
		case 4: str[11] = '4'; break;
		case 5: str[11] = '5'; break;
		case 6: str[11] = '6'; break;
		case 7: str[11] = '7'; break;
		case 8: str[11] = '8'; break;
		case 9: str[11] = '9'; break;
		}*/
//	else str[11] = ' ';

	str[13] = (value%10) + '0';

	/*
	switch (value%10){
	case 0: str[12] = '0'; break;
	case 1: str[12] = '1'; break;
	case 2: str[12] = '2'; break;
	case 3: str[12] = '3'; break;
	case 4: str[12] = '4'; break;
	case 5: str[12] = '5'; break;
	case 6: str[12] = '6'; break;
	case 7: str[12] = '7'; break;
	case 8: str[12] = '8'; break;
	case 9: str[12] = '9'; break;
	}*/

	return str;
}

int main (void){
	uint8_t state=1;
	volatile uint8_t old_t=-1;
	uint8_t title[]="***CRONOMETRO***";

	init_display7();
//	while(1){ 	display7_write_digit ('3', 1); DISP7EPORT |= (1<<DISP7E1);}

	lcd_init();
//		lcd_wr_inst(lcd_SetCursor | lcd_1line);
		lcd_wr_str(title);
		lcd_wr_inst(lcd_SetCursor | lcd_2line);
//		_delay_ms(4);
		lcd_wr_str(str_timer);
//	init_printf_tools();
	init_timers();
	define_ports();
	init_USART();

	usart_put_str(title, 0);
	usart_put_str("Clique para come�ar a contar.", 0);

	sei();

	while(1){
//		if (state != old){
//			printf("State = %d\n",state);
//			old=state;
//		}

		switch(state){
		// RESET DA CONTAGEM DO TEMPO
		case 1:
			if (!(PINC & (1<<START))){
				state=2;
				usart_put_str("A CONTAR...", 0);
				cli();
				TCNT0 = INIT_COUNTER;
				timer = 0;
				sei();
			}
			break;

		// ESTADO ENQUANTO TEMOS O BOT�O START PRESSIONADO
		case 2:
			if (PINC & (1<<START)) state = 3;
			if (timer != old_t){
				//printf("%d cs\n", timer);
				old_t=timer;

				// CONVERTE O TEMPO PARAUMA STRING
				*(str_timer) = convert_str(timer, str_timer);

				// ESCREVE  A STRING NUM LCD 16X2
				lcd_wr_inst(lcd_SetCursor | lcd_2line);
				lcd_wr_str(str_timer);

				// ESCREVE A STRING NA PORTA SERIE
//				usart_put_str(str_timer, 7);

				// ESCREVE A STRING EM 3 DISPLAY'S DE 7 SEGMENTOS
//				display7_print_time(str_timer);
			}
			break;

		// ESTADO QUANDO SOLTAMOS O BOT�O START
		case 3:
			if (timer != old_t){
			//	printf("%d cs\n", timer);
				old_t = timer;

				// CONVERTE O TEMPO PARAUMA STRING
				*(str_timer) = convert_str(timer, str_timer);

				// ESCREVE  A STRING NUM LCD 16X2
				lcd_wr_inst(lcd_SetCursor | lcd_2line);
				lcd_wr_str(str_timer);

				// ESCREVE A STRING NA PORTA SERIE
//				usart_put_str(str_timer, 7);

				// ESCREVE A STRING EM 3 DISPLAY'S DE 7 SEGMENTOS
//				display7_print_time(str_timer);
			}
			if (!(PINC & (1<<START))){
				usart_put_str(str_timer, 7);
				state = 1;// REINICIA A CONTAGEM DO TEMPO QUANDO PRESSIONAMOS NOVAMENTE START
			}

			if (!(PINC & (1<<STOP))) {
				usart_put_str(str_timer, 7);
				state = 1;// PARA A CONTAGEM DO TEMPO QUANDO CARREGAMOS EM STOP
			}
			break;
		}
	}
}
