/******************************************************************************************
 *
 * 	------------
 *  |       PB0|---------|	a
 *  |       PB1|---------|	b
 *  |       PB2|---------|	c
 *  |       PB3|---------|	d
 *  |       PB4|---------|	e
 *  |       PB5|---------|	f
 *  |       PB6|---------+	g	DISPLAY 7 SEG PORTS
 *  |          |
 *  |          |
 *  |          |
 *  |       PC4|---------- DISPLAY 1 ENABLE
 *  |       PC5|---------- DISPLAY 2 ENABLE
 *  |       PB6|---------- DISPLAY 3 ENABLE
 *  ------------
 *
 *  NOTA: Nesta biblioteca n�o est� definida a utiliza��o do ponto -- entrada DP do display, ela
 *  	  dever� ser ligada � massa
 **********************************************************************************************/

#include <avr/io.h>
#include <util/delay.h>

// Define as portas dos diferentes leds dos displays
#define SHREGPORT	PORTB
#define SHREGDDR	DDRB
#define SHREGDATA	PB0
#define SHREGCLK	PB2
#define SHREGSTORE	PB1

// Define os diferentes display multiplexados
#define DISP7EPORT	PORTB
#define DISP7EDDR	DDRB
#define DISP7E1		PB3
#define DISP7E2		PB4
#define DISP7E3		PB5

// Define os algarismos a escrever em cada display
#define ALG1 0b00000110 // 0b01100000
#define ALG2 0b01011011 //0b11011010
#define ALG3 0b01001111 // 0b11110010
#define ALG4 0b00100110 // 0b01100100
#define ALG5 0b01101101 //0b10110110
#define ALG6 0b01111101 //0b10111110
#define ALG7 0b00000111 //0b11100000
#define ALG8 0b01111111 //0b11111110
#define ALG9 0b01101111 //0b11110110
#define ALG0 0b00111111 //0b11111100
/******************************************************************
 * Name:     init_display7
 * Purpose:  Inicializa o display -- define as portas como sa�das
 * Entry:    Sem par�metros
 * Exit:     Sem par�metros
 * Notes:
 */
void init_display7 (void);

/******************************************************************
 * Name:     display7_print_time
 * Purpose:  Imprime o tempo em 3 displays
 * Entry:    time[]
 * Exit:     Sem par�metros
 * Notes:    As "string" devem estar no tipo uint8_t
 */
void display7_print_time (uint8_t time[17], uint8_t display);

/******************************************************************
 * Name:     display7_write_digit
 * Purpose:  Escreve um algarismo
 * Entry:    digit
 * Exit:     Sem par�metros
 * Notes:    O digito deve estar no formato uint8_t
 */
void display7_write_digit (uint8_t digit, uint8_t display);

/******************************************************************
 * Name:     shift_register_send_data
 * Purpose:  Escreve os dados para o shift register
 * Entry:    data
 * Exit:     Sem par�metros
 * Notes:
 */
void shift_register_send_data (uint8_t data, uint8_t dislay);
