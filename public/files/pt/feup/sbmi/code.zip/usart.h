/*
 * usart.h
 *
 *  Created on: 08/12/2015
 *      Author: sandr
 */

#define F_CPU 16000000UL
#define baud 57600
#define baudgen ((F_CPU/(16*baud))-1)
#define INIT_COUNTER (65535-20000)

/******************************************************************
 * Name:     init_usart
 * Purpose:  Inicializa as comunica��es por via assincrona
 * Entry:    Sem par�metros
 * Exit:     Sem par�metros
 * Notes:    Comunica��es a uma cad�ncia de 57600
*/
void init_USART (void);

/******************************************************************
 * Name:     usart_put_character
 * Purpose:  Imprime 1 caracter pela porta s�rie
 * Entry:    character
 * Exit:     Sem par�metros
 * Notes:    Os caracteres devem estar no tipo uint8_t
 */
void usart_put_character (uint8_t character);

/******************************************************************
 * Name:     usart_put_str
 * Purpose:  Imprime 1 string pela porta s�rie
 * Entry:    str, pos
 * Exit:     Sem par�metros
 * Notes:    As "string" devem estar no tipo uint8_t
 */
void usart_put_str (uint8_t str[], uint8_t pos);
