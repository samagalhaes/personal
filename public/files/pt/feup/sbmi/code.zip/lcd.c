/*
 * lcd.c
 *
 *  Created on: 02/12/2015
 *      Author: sandr
 */

/***************************************************************************

            The four data lines as well as the two control lines may be
              implemented on any available I/O pin of any port.  These are
              the connections used for this program:

                 -----------                   ----------
                | ATmega328 |                 |   LCD    |
                |           |                 |          |
                |        PD7|---------------->|D7        |
                |        PD6|---------------->|D6        |
                |        PD5|---------------->|D5        |
                |        PD4|---------------->|D4        |
                |           |                 |D3        |
                |           |                 |D2        |
                |           |                 |D1        |
                |           |                 |D0        |
                |           |                 |          |
                |        PD3|---------------->|E         |
                |           |         GND --->|RW        |
                |        PD2|---------------->|RS        |
                 -----------                   ----------

  **************************************************************************/

#define F_CPU 16000000UL

#include <util/delay.h>
#include <avr/io.h>
#include "lcd.h"

/*** Configure Instructions Commands ***/
#define lcd_clear 			0b00000001
#define lcd_cursorhome	 	0b00000010
#define lcd_on 				0b00001100
#define lcd_off 			0b00001000
#define lcd_mode 			0b00101000 //0b00101000
#define lcd_entrymode 		0b00000110
#define lcd_SetCursor 		0b10000000
#define lcd_FunctionReset	0b00110000

/*** Configure LCD Pins ***/
#define LCD_RS PD2
#define LCD_E PD3
#define LCD_PORT PORTD
#define LCD_DDR DDRD

/*** Configure LCD Pins ***/
#define DATA4 PD4
#define DATA5 PD5
#define DATA6 PD6
#define DATA7 PD7
#define DATA_PORT PORTD
#define DATA_DDR DDRD





/*** LCD Function ***/
void lcd_init(void){
	LCD_DDR |= (1<<LCD_E) | (1<<LCD_RS);
	DATA_DDR |= (1<<DATA7) |(1<<DATA6) |(1<<DATA5) | (1<<DATA4);

	_delay_ms(100);

	LCD_PORT &= ~((1<<LCD_RS)|(1<<LCD_E));

//	LCD_PORT |= (1<<LCD_RS);
	lcd_write(lcd_FunctionReset);
	_delay_ms(10);
	lcd_write(lcd_FunctionReset);
	_delay_us(200);
	lcd_write(lcd_FunctionReset);
	_delay_us(200);



	lcd_write(lcd_mode);
	_delay_us(80);
	lcd_wr_inst(lcd_mode);
	_delay_us(80);

	lcd_wr_inst(lcd_off);
//	lcd_wr_inst(4<<lcd_off);
	_delay_us(80);

	lcd_wr_inst(lcd_clear);
//	lcd_wr_inst(4<<lcd_clear);
	_delay_ms(4);

	lcd_wr_inst(lcd_entrymode);
//	lcd_wr_inst(4<<lcd_entrymode);
	_delay_us(80);

	lcd_wr_inst(lcd_on);
//	lcd_wr_inst(4<<lcd_on);
	_delay_us(80);

}

void lcd_wr_str (uint8_t str[]){
	volatile int i=0;

	while(str[i] != 0){
		lcd_wr_char(str[i]);
		i++;
		_delay_us(80);
	}
}

void lcd_wr_char (uint8_t data){
	LCD_PORT |= (1<<LCD_RS);
	LCD_PORT &= ~(1<<LCD_E);

	lcd_write (data);
	lcd_write (data << 4);
}

void lcd_wr_inst (uint8_t instruction){
	LCD_PORT &= ~(1<<LCD_RS);
	LCD_PORT &= ~(1<<LCD_E);
	lcd_write (instruction);
	lcd_write (instruction << 4);
}

void lcd_write (uint8_t byte){
	DATA_PORT &= ~((1<<DATA7) | (1<<DATA6) | (1<<DATA5) | (1<<DATA4));

	if (byte & 1<<7) DATA_PORT |= (1<<DATA7);
	if (byte & 1<<6) DATA_PORT |= (1<<DATA6);
	if (byte & 1<<5) DATA_PORT |= (1<<DATA5);
	if (byte & 1<<4) DATA_PORT |= (1<<DATA4);

	LCD_PORT |= (1<<LCD_E);
	_delay_us(1);
	LCD_PORT &= ~(1<<LCD_E);
	_delay_us(1);
}

	_delay_us(1);
}
