/******************************************************************************************
 *
 * 	------------
 *  |       PB0|---------|	a
 *  |       PB1|---------|	b
 *  |       PB2|---------|	c
 *  |       PB3|---------|	d
 *  |       PB4|---------|	e
 *  |       PB5|---------|	f
 *  |       PB6|---------+	g	DISPLAY 7 SEG PORTS
 *  |          |
 *  |          |
 *  |          |
 *  |       PC4|---------- DISPLAY 1 ENABLE
 *  |       PC5|---------- DISPLAY 2 ENABLE
 *  |       PB6|---------- DISPLAY 3 ENABLE
 *  ------------
 *
 *  NOTA: Nesta biblioteca n�o est� definida a utiliza��o do ponto -- entrada DP do display, ela
 *  	  dever� ser ligada � massa
 **********************************************************************************************/

#include <avr/io.h>
//#include <util/delay.h>
#include <util/delay.h>
#include "display7.h"

// Define as portas dos diferentes leds dos displays
#define SHREGPORT	PORTB
#define SHREGDDR	DDRB
#define SHREGDATA	PB0
#define SHREGCLK	PB2
#define SHREGSTORE	PB1

// Define os diferentes display multiplexados
#define DISP7EPORT	PORTB
#define DISP7EDDR	DDRB
#define DISP7E1		PB3
#define DISP7E2		PB4
#define DISP7E3		PB5

// Define os algarismos a escrever em cada display
#define ALG1 0b01100000
#define ALG2 0b11011010
#define ALG3 0b11110010
#define ALG4 0b01100110
#define ALG5 0b10110110
#define ALG6 0b10111110
#define ALG7 0b11100000
#define ALG8 0b11111110
#define ALG9 0b11110110
#define ALG0 0b11111100

/******************************************************************
 * Name:     init_display7
 * Purpose:  Inicializa o display -- define as portas como sa�das
 * Entry:    Sem par�metros
 * Exit:     Sem par�metros
 * Notes:    O pino DP do display deve ser ligado ao GND
 */
void init_display7 (void){
	SHREGDDR |= (1<<SHREGCLK | 1<<SHREGDATA | 1<<SHREGSTORE);
	SHREGPORT &= ~((1<<SHREGCLK) | (1<<SHREGDATA) | (1<<SHREGSTORE));

	DISP7EDDR |= (1<<DISP7E1) | (1<<DISP7E2) | (1<<DISP7E3);
	DISP7EPORT &= ~((1<<DISP7E1) | (1<<DISP7E2) | (1<<DISP7E3));
}

/******************************************************************
 * Name:     display7_print_time
 * Purpose:  Imprime o tempo em 3 displays
 * Entry:    time[]
 * Exit:     Sem par�metros
 * Notes:    As "string" devem estar no tipo uint8_t
 */
void display7_print_time (uint8_t time[17], uint8_t display){
	DISP7EPORT &= ~((1<<DISP7E3) | (1<<DISP7E2) | (1<<DISP7E1));

	// ESCREVE O ALGARISMO DAS CENTENAS
	if (display == 1){
		display7_write_digit(time[9], 1);
		DISP7EPORT |= (1<<DISP7E1);
	}

	// ESCREVE O ALGARISMO DAS DEZENAS
	if (display == 2){
		display7_write_digit(time[10], 2);
		DISP7EPORT |= (1<<DISP7E2);
	}

	// ESCREVE O ALGARISMO DAS UNIDADES
	if (display == 3){
		display7_write_digit(time[12], 3);
		DISP7EPORT |= (1<<DISP7E3);
	}

}

/******************************************************************
 * Name:     display7_write_digit
 * Purpose:  Escreve um algarismo
 * Entry:    digit, display
 * Exit:     Sem par�metros
 * Notes:    O digito deve estar no formato uint8_t
 */
void display7_write_digit (uint8_t digit, uint8_t display){
//	DISP7EPORT &= ~((1<<DISP7E1) | (1<<DISP7E2) | (1<<DISP7E3));

//	if (display == 2) digit|= 0b10000000;

	switch (digit){
	case ' ':
	case '0': shift_register_send_data(~ALG0, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '1': shift_register_send_data(~ALG1, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '2': shift_register_send_data(~ALG2,display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '3': shift_register_send_data(~ALG3,display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '4': shift_register_send_data(~ALG4,display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '5': shift_register_send_data(~ALG5, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '6': shift_register_send_data(~ALG6, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '7': shift_register_send_data(~ALG7, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '8': shift_register_send_data(~ALG8, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	case '9': shift_register_send_data(~ALG9, display);
		SHREGPORT |= (1<<SHREGSTORE);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGSTORE);
		break;
	}
}

/******************************************************************
 * Name:     shift_register_send_data
 * Purpose:  Escreve os dados para o shift register
 * Entry:    data, display
 * Exit:     Sem par�metros
 * Notes:
 */
void shift_register_send_data (uint8_t data, uint8_t display){
	uint8_t i=0;

	if (display == 2) data&= ~(0b00000001);

	while (i<8){
		SHREGPORT &= ~(1<<SHREGDATA);

		if (data & (1<<0)) SHREGPORT |= (1<<SHREGDATA);

		SHREGPORT |= (1<<SHREGCLK);
		_delay_us(5);
		SHREGPORT &= ~(1<<SHREGCLK);

		data = (data>>1);
		i++;
	}
}
