/*
 * usart.c
 *
 *  Created on: 08/12/2015
 *      Author: sandr
 */

#include <avr/io.h>

#define F_CPU 16000000UL
#define baud 57600
#define baudgen ((F_CPU/(16*baud))-1)

/******************************************************************
 * Name:     init_usart
 * Purpose:  Inicializa as comunica��es por via assincrona
 * Entry:    Sem par�metros
 * Exit:     Sem par�metros
 * Notes:    Comunica��es a uma cad�ncia de 57600
*/
void init_USART (void){
	  UBRR0 = baudgen;
	  UCSR0B = (1<<RXEN0)|(1<<TXEN0);
	  UCSR0C = (1<<USBS0)|(3<<UCSZ00);
}

/******************************************************************
 * Name:     usart_put_character
 * Purpose:  Imprime 1 caracter pela porta s�rie
 * Entry:    character
 * Exit:     Sem par�metros
 * Notes:    Os caracteres devem estar no tipo uint8_t
 */
void usart_put_character (uint8_t character){
		// Verifica que a porta s�rie n�o  est� aescrever
	while ((UCSR0A & (1<<UDRE0)) == 0);

		// Escreve o caracter para a porta s�rie
	UDR0 = character;
}

/******************************************************************
 * Name:     usart_put_str
 * Purpose:  Imprime 1 string pela porta s�rie
 * Entry:    str, pos
 * Exit:     Sem par�metros
 * Notes:    As "string" devem estar no tipo uint8_t
 */
void usart_put_str (uint8_t str[], uint8_t pos){
	while (str[pos]!=0){
		usart_put_character(str[pos]);
		pos++;
	}
	usart_put_character('\n');
}
